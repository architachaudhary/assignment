document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('main');
    const ctx = canvas.getContext('2d');
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;
    let brushSize = 5;
    let color = 'black';
  
    // Function to draw on canvas
    function draw(e) {
      if (!isDrawing) return;
      ctx.strokeStyle = color;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.lineWidth = brushSize;
      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(e.offsetX, e.offsetY);
      ctx.stroke();
      [lastX, lastY] = [e.offsetX, e.offsetY];
    }
    
    // Event listeners for mouse actions
    canvas.addEventListener('mousedown', (e) => {
      isDrawing = true;
      [lastX, lastY] = [e.offsetX, e.offsetY];
    });
  
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', () => isDrawing = false);
    canvas.addEventListener('mouseout', () => isDrawing = false);
    
    // Event listener for eraser button
    document.getElementById('erase').addEventListener('click', function() {
        // Set color to white for eraser
        color = 'white'; 
    });
  
    // Event listener for new canvas button
    document.getElementById('new').addEventListener('click', function() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    });
    
    // Event listeners for brush color buttons
    document.getElementById('black').addEventListener('click', function() {
      color = 'black';
    });
  
    document.getElementById('pink').addEventListener('click', function() {
      color = '#F50057';
    });
  
    document.getElementById('blue').addEventListener('click', function() {
      color = '#2979FF';
    });
  
    document.getElementById('yellow').addEventListener('click', function() {
      color = '#FFD600';
    });
    
    // Event listener for brush size slider
    document.getElementById('slider').addEventListener('input', function(e) {
      brushSize = e.target.value;
      document.getElementById('brushSize').textContent = brushSize;
    });
  });
